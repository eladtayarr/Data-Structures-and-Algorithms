package LinkedList;

import java.util.Random;

public class Train {
	
	public static int lengthTrain(BoolNode Head) {
		int Length = 0; 
		BoolNode Head_copy = Head;
		BoolNode Pointer = Head; 
		boolean FirstNode = true;
		Head.setInfo(true); 
		
		while(Pointer != Head || FirstNode ) {
			Length ++;
			BoolNode node = Head_copy;
			boolean firstnode = true;
			
			if(Pointer.getInfo()==true) {
				Pointer.setInfo(false);
				node.setInfo(false);
				for(int i = 0 ; i < Length ; i ++) {
					node.getPrev();
				}
				while(node != Head_copy || firstnode) {
					System.out.print(node.getInfo()+" ");
					node = node.getNext();
					firstnode=false;
				}
				for(int i  = 0 ; i < Length ; i++) {
					node.getNext(); 
				}
				System.out.println();
			}
			Pointer = Pointer.getNext();
			node.getNext();
			FirstNode=false;
			}
		
		System.out.println();
		System.out.println("The Length of this list is: ");
		return Length;
		}

	public static void main(String[] args) {
        Random random = new Random();
        BoolNode Head = null; 
        BoolNode Tail = null;
        int Size = random.nextInt(25, 41); 
        
        System.out.print("The original list is:  \n");
        for(int i = 0 ; i < Size ; i ++) {
        	boolean inside = random.nextBoolean();
        	BoolNode TheNode = new BoolNode(inside); 
        	
        	if(Head == null) { 
        		Head = TheNode; 
        		Tail = TheNode; 
        	}
        	else { 
        		Tail.setNext(TheNode);
        		TheNode.setPrev(Tail);
        		Tail = TheNode;
        	}
        	System.out.print(Tail.getInfo()+" "); 
        }
        Tail.setNext(Head);
        Head.setPrev(Tail);
       
        System.out.println();
        System.out.println(lengthTrain(Head));
    }
}