package TelAviv;
public class TelavivTowers{
	
	public static int TelAvivTowers(int A[]) {
		
		Stack stack = new Stack();
		stack.push(0);
		int X = 1;
		System.out.println("The building at index: 0 , has a Sea view 0. \n");
		
		while (X < A.length) {
			if(stack.isEmpty()) {
				System.out.println("The building at index: "+X+", has a Sea view 0. \n");
				stack.push(X);
				X++;
			}
			else if(A[X]<A[stack.top()]){
				System.out.println("The building at index: "+X+", looks at the building: "+stack.top()+". \n");
				stack.push(X);
				X++;
			}
			else {
				stack.pop();
			}
		}
		return -1;
		
	}
	
	
		public static void main(String[] args){
			int []A = {123, 28, 23, 144, 75, 194, 72, 59, 72, 130, 122, 163, 158, 168, 119, 114, 88, 64, 110, 108, 187, 88, 116, 200, 2, 90, 23, 85, 107, 126};
			TelAvivTowers(A);
		}
	}